// DataChild1.h: interface for the DataChild1 class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_DATACHILD1_H__72FDD3D0_0E08_4BE5_A8AD_549CF61186AB__INCLUDED_)
#define AFX_DATACHILD1_H__72FDD3D0_0E08_4BE5_A8AD_549CF61186AB__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "DataBase.h"

class DataChild1 : public DataBase  
{
public:
	DataChild1();
	void Init();
	virtual ~DataChild1();

};

#endif // !defined(AFX_DATACHILD1_H__72FDD3D0_0E08_4BE5_A8AD_549CF61186AB__INCLUDED_)
