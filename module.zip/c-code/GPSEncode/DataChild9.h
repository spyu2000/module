// DataChild9.h: interface for the DataChild9 class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_DATACHILD9_H__5968FB99_5900_457A_A746_DD36600833D0__INCLUDED_)
#define AFX_DATACHILD9_H__5968FB99_5900_457A_A746_DD36600833D0__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "DataBase.h"

class DataChild9 : public DataBase  
{
public:
	DataChild9();
	void Init();
	virtual ~DataChild9();

};

#endif // !defined(AFX_DATACHILD9_H__5968FB99_5900_457A_A746_DD36600833D0__INCLUDED_)
