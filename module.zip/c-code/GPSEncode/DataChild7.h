// DataChild7.h: interface for the DataChild7 class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_DATACHILD7_H__C4C69562_7E56_4448_B83B_6C527E417FCC__INCLUDED_)
#define AFX_DATACHILD7_H__C4C69562_7E56_4448_B83B_6C527E417FCC__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "DataBase.h"

class DataChild7 : public DataBase 
{
public:
	DataChild7();
	void Init();
	virtual ~DataChild7();

};

#endif // !defined(AFX_DATACHILD7_H__C4C69562_7E56_4448_B83B_6C527E417FCC__INCLUDED_)
