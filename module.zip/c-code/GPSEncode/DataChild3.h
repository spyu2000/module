// DataChild3.h: interface for the DataChild3 class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_DATACHILD3_H__3BD8968D_88D0_4E26_AF2E_3885EF67ACE8__INCLUDED_)
#define AFX_DATACHILD3_H__3BD8968D_88D0_4E26_AF2E_3885EF67ACE8__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "DataBase.h"

class DataChild3 : public DataBase  
{
public:
	DataChild3();
	void Init();
	virtual ~DataChild3();

};

#endif // !defined(AFX_DATACHILD3_H__3BD8968D_88D0_4E26_AF2E_3885EF67ACE8__INCLUDED_)
