// DataChild4.h: interface for the DataChild4 class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_DATACHILD4_H__60B29FA0_6D1A_4BD2_A55F_BB1DECBABB6D__INCLUDED_)
#define AFX_DATACHILD4_H__60B29FA0_6D1A_4BD2_A55F_BB1DECBABB6D__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "DataBase.h"

class DataChild4 : public DataBase  
{
public:
	DataChild4();
	void Init();
	virtual ~DataChild4();

};

#endif // !defined(AFX_DATACHILD4_H__60B29FA0_6D1A_4BD2_A55F_BB1DECBABB6D__INCLUDED_)
