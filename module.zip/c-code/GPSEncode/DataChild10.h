// DataChild10.h: interface for the DataChild10 class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_DATACHILD10_H__8584D3F9_4E3F_4F88_9605_0E36C5624F99__INCLUDED_)
#define AFX_DATACHILD10_H__8584D3F9_4E3F_4F88_9605_0E36C5624F99__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "DataBase.h"

class DataChild10 : public DataBase  
{
public:
	DataChild10();
	void Init();
	virtual ~DataChild10();

};

#endif // !defined(AFX_DATACHILD10_H__8584D3F9_4E3F_4F88_9605_0E36C5624F99__INCLUDED_)
