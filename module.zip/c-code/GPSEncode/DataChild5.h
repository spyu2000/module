// DataChild5.h: interface for the DataChild5 class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_DATACHILD5_H__838BEB9A_7107_4C9F_B026_951B50633DC1__INCLUDED_)
#define AFX_DATACHILD5_H__838BEB9A_7107_4C9F_B026_951B50633DC1__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "DataBase.h"

class DataChild5 : public DataBase  
{
public:
	DataChild5();
	void Init();
	virtual ~DataChild5();

};

#endif // !defined(AFX_DATACHILD5_H__838BEB9A_7107_4C9F_B026_951B50633DC1__INCLUDED_)
