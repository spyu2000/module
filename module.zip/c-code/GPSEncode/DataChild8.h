// DataChild8.h: interface for the DataChild8 class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_DATACHILD8_H__3ECB21E1_777D_4124_9943_91F5112B29E6__INCLUDED_)
#define AFX_DATACHILD8_H__3ECB21E1_777D_4124_9943_91F5112B29E6__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "DataBase.h"

class DataChild8 : public DataBase  
{
public:
	DataChild8();
	void Init();
	virtual ~DataChild8();

};

#endif // !defined(AFX_DATACHILD8_H__3ECB21E1_777D_4124_9943_91F5112B29E6__INCLUDED_)
