// DataChild2.h: interface for the DataChild2 class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_DATACHILD2_H__4F43A316_9185_4A91_AC07_271C5E776F02__INCLUDED_)
#define AFX_DATACHILD2_H__4F43A316_9185_4A91_AC07_271C5E776F02__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "DataBase.h"

class DataChild2 : public DataBase  
{
public:
	DataChild2();
	void Init();
	virtual ~DataChild2();

};

#endif // !defined(AFX_DATACHILD2_H__4F43A316_9185_4A91_AC07_271C5E776F02__INCLUDED_)
