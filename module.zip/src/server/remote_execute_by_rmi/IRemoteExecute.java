package server.remote_execute_by_rmi;

import com.fleety.base.InfoContainer;

public interface IRemoteExecute{
    public Object execute(InfoContainer para);
}
