package server.manager.app.autoupdate.info;

import java.io.Serializable;

public interface IObjForInter extends Serializable{
	public String getInfoType();
}
