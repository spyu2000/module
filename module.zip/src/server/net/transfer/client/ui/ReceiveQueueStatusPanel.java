package server.net.transfer.client.ui;

import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.SwingUtilities;
import javax.swing.table.DefaultTableModel;

import com.fleety.base.ui.XjsTable;

import server.net.transfer.IDataListener;
import server.net.transfer.ITransfer;
import server.net.transfer.container.QueueContainer.QueueItemInfo;
import server.socket.inter.ConnectSocketInfo;

public class ReceiveQueueStatusPanel extends JPanel  implements IDataListener{
	private ITransfer transferClient = null;
	private SendAndReceiveMonitorServer server = null;
	public ReceiveQueueStatusPanel(SendAndReceiveMonitorServer server){
		this.server = server;
		this.initPanel();
		this.transferClient = this.server.getNetTransferClient();
		this.transferClient.addDataReceiveListener(this);
		this.updateStatus();
	}

	private String[] colNameArr = new String[]{"���","������Ϣ","����·��","�������(%)"};
	private XjsTable receiveTable = null;
	private void initPanel(){
		this.setLayout(null);
		this.receiveTable = new XjsTable(colNameArr);
		JScrollPane scrollPane = new JScrollPane(this.receiveTable);
		this.receiveTable.getColumn(colNameArr[0]).setPreferredWidth(70);
		this.receiveTable.getColumn(colNameArr[1]).setPreferredWidth(210);
		this.receiveTable.getColumn(colNameArr[2]).setPreferredWidth(350);
		this.receiveTable.getColumn(colNameArr[3]).setPreferredWidth(120);
		scrollPane.setBounds(20, 80, 750, 550);
		this.add(scrollPane);
	}
	
	private void updateStatus(){
		this.clearTable();
		ITransfer transferClient = this.server.getNetTransferClient();
		QueueItemInfo[] arr = transferClient.getReceiveQueueContainer().getAllQueueItemInfo();
		DefaultTableModel model = (DefaultTableModel)this.receiveTable.getModel();
		for(int i=0;i<arr.length;i++){
			model.addRow(new String[]{(i+1)+"",arr[i].appendInfo==null?"":arr[i].appendInfo,arr[i].id,arr[i].getProgress()+""});
		}
	}
	
	private void clearTable(){
		DefaultTableModel model = (DefaultTableModel)this.receiveTable.getModel();
		while(model.getRowCount() > 0){
			model.removeRow(0);
		}
	}
	
	public void connect(ConnectSocketInfo connInfo,boolean isPrimary){}
	public void disconnect(ConnectSocketInfo connInfo,boolean isPrimary){}
	
	public void dataArrived(ITransfer transfer,QueueItemInfo dataInfo,int process){}
	public void dataSended(ITransfer transfer,QueueItemInfo dataInfo,int process){
		if(dataInfo.getQueueContainer() != this.transferClient.getReceiveQueueContainer()){
			return ;
		}
		SwingUtilities.invokeLater(new Runnable(){
			public void run(){
				updateStatus();
			}
		});
	}
	public void taskChanged(ITransfer transfer,QueueItemInfo dataInfo){
		if(dataInfo.getQueueContainer() != this.transferClient.getReceiveQueueContainer()){
			return ;
		}
		SwingUtilities.invokeLater(new Runnable(){
			public void run(){
				updateStatus();
			}
		});
	}
}
