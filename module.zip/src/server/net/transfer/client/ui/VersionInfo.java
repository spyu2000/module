package server.net.transfer.client.ui;

public class VersionInfo {
	public static final String CLIENT_VERSION = "1.1.3";
}
