/**
 * ���� Created on 2008-6-17 by edmund
 */
package server.socket.socket;

import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.nio.channels.SelectionKey;
import java.nio.channels.Selector;
import java.nio.channels.SocketChannel;
import java.util.Iterator;

import server.socket.inter.CmdInfo;
import server.socket.inter.ConnectSocketInfo;
import server.socket.inter.ICmdReader;
import server.socket.inter.ICmdReleaser;
import server.threadgroup.PoolInfo;
import server.threadgroup.ThreadPoolGroupServer;

import com.fleety.base.FleetyThread;
import com.fleety.server.BasicServer;
import com.fleety.util.pool.thread.BasicTask;
import com.fleety.util.pool.thread.ThreadPool;
import com.fleety.util.pool.timer.FleetyTimerTask;

/**
 * ��װSocket���ӵĿͻ��ˣ�ͨ��ָ���������Ķ����Լ���������������ݵĶ�ȡ��
 * ���ݵķ��Ϳ���ͨ���ӿ�sendData�������Ӻ����ⲿ֪ͨ��ConnetSocketInfo�������
 * @title
 * @description
 * @version      1.0
 * @author       edmund
 *
 */
public class FleetySocket extends BasicServer{
	//��Ҫ֧�ֵĲ�����ʶ���ֱ�Ϊ�����Ķ������ͷ����Լ���������ip�Ͷ˿�
	public static final String CMD_READER_FLAG = "reader";
	public static final String CMD_RELEASER_FLAG = "releaser";
	public static final String SERVER_IP_FLAG = "ip";
	public static final String SERVER_PORT_FLAG = "port";
	public static final String SERVER_IP_BAK_FLAG = "ip_bak";
	public static final String SERVER_PORT_BAK_FLAG = "port_bak";
	public static final String AUTO_CONNECT_CYCLE_FLAG = "connect_cycle";
	
	public static final String DETECT_TIMEOUT_FLAG = "detect_timeout";
	public static final String DETECT_CYCLE_FLAG = "detect_cycle";
	public static final String TIME_OUT_FLAG = "timeout";

	private boolean isStartTimeoutDetect = false;
	private long detectCycle = 2*60*1000l;
	private long timeout = 5*60*1000l;
	
	private ConnectSocketInfo connInfo = null;
	
	private DetectThread readThread = null;
	
	private String ip_cur = null;
	private int port_cur = 0;

	private String ip = null;
	private int port = 0;

	private String ip_bak = null;
	private int port_bak = 0;
	
	private boolean isMain_current=true;
	
	private int connectCycle = 60000;
	
	private Selector selector = null;
	
	private ICmdReader cmdReader = null;
	private ICmdReleaser cmdReleaser = null;

	/**
	 * ��������
	 */
	public boolean startServer(){		
		try{
			this.ip = this.getStringPara(SERVER_IP_FLAG);
			this.ip_cur=this.ip;
			
			String tempStr = this.getStringPara(SERVER_PORT_FLAG);
			if(tempStr != null && tempStr.trim().length() > 0){
				this.port = Integer.parseInt(tempStr.trim());
			}else{
				throw new Exception("����˿�����!");
			}
			this.port_cur=this.port;
			
			tempStr = this.getStringPara(SERVER_IP_BAK_FLAG);
			if(tempStr != null && tempStr.trim().length() > 0){
				this.ip_bak = tempStr;

				tempStr = this.getStringPara(SERVER_PORT_BAK_FLAG);
				if(tempStr != null && tempStr.trim().length() > 0){
					this.port_bak = Integer.parseInt(tempStr.trim());
				}else{
					throw new Exception("����ı��ö˿�����!");
				}
			}
			
			
		}catch(Exception e){
			e.printStackTrace();
			return false;
		}
		
		try{
			String str = this.getStringPara(AUTO_CONNECT_CYCLE_FLAG);
			if(str != null){
				this.connectCycle = Integer.parseInt(str);
			}
		}catch(Exception e){
			e.printStackTrace();
		}
		
		try{
			String tempStr = this.getStringPara(CMD_READER_FLAG);
			Class cls = Class.forName(tempStr.trim());
			Object tempObj = cls.newInstance();
			this.cmdReader = (ICmdReader)tempObj;
			this.cmdReader.init(this);
		}catch(Exception e){
			e.printStackTrace();
			System.out.println("�����Ķ���ʵ����ʧ��!");
			return false;
		}
		
		try{
			String tempStr = this.getStringPara(CMD_RELEASER_FLAG);
			Class cls = Class.forName(tempStr.trim());
			Object tempObj = cls.newInstance();
			this.cmdReleaser = (ICmdReleaser)tempObj;
			this.cmdReleaser.init(this);
		}catch(Exception e){
			e.printStackTrace();
			System.out.println("���������ʵ����ʧ��!");
			return false;
		}
		
		try{
			this.selector = Selector.open();
		}catch(Exception e){
			e.printStackTrace();
			return false;
		}
		
		this.readThread = new DetectThread();
		this.readThread.start();

		String tempStr;
		try{
			tempStr = this.getStringPara(DETECT_CYCLE_FLAG);
			if(tempStr != null){
				this.detectCycle = Integer.parseInt(tempStr.trim());
			}
			tempStr = this.getStringPara(TIME_OUT_FLAG);
			if(tempStr != null){
				this.timeout = Integer.parseInt(tempStr.trim());
			}
			tempStr = this.getStringPara(DETECT_TIMEOUT_FLAG);
			if(tempStr != null){
				this.isStartTimeoutDetect = tempStr.trim().equalsIgnoreCase("true");
			}
		}catch(Exception e){
			e.printStackTrace();
		}


		ThreadPoolGroupServer.getSingleInstance().createTimerPool(FleetySocket.this.getServerName()
				+ "[" + FleetySocket.this.hashCode() + "]").schedule(new FleetyTimerTask(){
			public void run(){
				switchSocket();
			}
		}, this.connectCycle, this.connectCycle);

		if(this.isStartTimeoutDetect){
			ThreadPoolGroupServer.getSingleInstance().createTimerPool(FleetySocket.this.getServerName()
					+ "[" + FleetySocket.this.hashCode() + "]").schedule(new FleetyTimerTask(){
				public void run(){

					ConnectSocketInfo tempConn = FleetySocket.this.connInfo;
					if(tempConn != null){
						if(System.currentTimeMillis()
								- tempConn.getLastActiveTime() >= timeout){
							FleetySocket.this._closeSocket();
						}
					}
				}
			}, this.detectCycle, this.detectCycle);
		}
		this.isRunning = true;
		return true;
	}

	/**
	 * �رշ���
	 */
	public synchronized void stopServer(){
		if(this.readThread != null){
			this.readThread.stopThread();
		}

		ThreadPoolGroupServer.getSingleInstance().destroyTimer(FleetySocket.this.getServerName()
				+ "[" + FleetySocket.this.hashCode() + "]");

		this.ip = null;
		if(this.connInfo != null){
			this.connInfo.closeSocket();
		}
		if(this.selector != null){
			try{
				this.selector.wakeup();
				this.selector.close();
			}catch(Exception e){}
			this.selector = null;
		}
		
		this.isRunning = false;
	}
	
	/**
	 * ����Socket����
	 * @return true�����ɹ�����֮����ʧ��
	 */
	public synchronized boolean connectSocket(){
		if(this.isConnected()){
			return true;
		}
		this._closeSocket();

		if(this.ip_cur == null){
			return false;
		}
		try{
			SocketChannel channel = SocketChannel.open();
			channel.configureBlocking(false);
			System.out.println("���ӵ�ַ��"+this.ip_cur+":"+this.port_cur);
			channel.connect(new InetSocketAddress(InetAddress.getByName(this.ip_cur),this.port_cur));
			
			//�첽�ͻ������ӵ����⡣���ӿ���δ��ɼ�ִ���������룬������Ҫ�ڴ˴��жϣ�����ע����selector�н���Ч��
			if(channel.isConnectionPending()){
				while(!channel.finishConnect()){
					FleetyThread.sleep(10);
				}
			}

			channel.socket().setSoLinger(false, 0);
			this.connInfo = new ConnectSocketInfo(channel,this);
			SelectionKey sKey;
			synchronized(this){
				this.selector.wakeup();
				sKey = channel.register(this.selector, SelectionKey.OP_READ, this.connInfo);
			}
			this.connInfo.setSelectionKey(sKey);
			
			CmdInfo cmdInfo = new CmdInfo();
			cmdInfo.setInfo(CmdInfo.CMD_FLAG, CmdInfo.SOCKET_CONNECT_CMD);
			cmdInfo.setInfo(CmdInfo.SOCKET_FLAG, this.connInfo);
			this.cmdReleaser.releaseCmd(cmdInfo);
		}catch(Exception e){
			e.printStackTrace();
			this._closeSocket();
			return connectSocketBak();
		}
		
		return true;
	}
	

	/**
	 * ����Socket����
	 * @return true�����ɹ�����֮����ʧ��
	 */
	public synchronized boolean connectSocketBak(){
		try{
			if(!isMain_current)
			{
				return false;
			}
			
			if(this.ip_bak == null){
				return false;
			}
			
			this.ip_cur=this.ip_bak;
			this.port_cur=this.port_bak;
			this.isMain_current=false;
			System.out.println("���ӱ��õ�ַ��"+this.ip_cur+":"+this.port_cur);
			return this.connectSocket();
		}catch(Exception e){
			e.printStackTrace();
			return false;
		}
	}
	/**
	 * �رյ�ǰ�����ӡ�
	 */
	private synchronized void _closeSocket(){
		ConnectSocketInfo conn = this.connInfo;
		this.connInfo = null;
		if(conn != null){
			conn.destroy();
			
			CmdInfo cmdInfo = new CmdInfo();
			cmdInfo.setInfo(CmdInfo.CMD_FLAG, CmdInfo.SOCKET_DISCONNECT_CMD);
			cmdInfo.setInfo(CmdInfo.SOCKET_FLAG, conn);
			this.cmdReleaser.releaseCmd(cmdInfo);
		}
	}
	public void closeSocket(){
		this._closeSocket();
		this.selector.wakeup();
	}
	
	public ConnectSocketInfo getConnInfo(){
		return this.connInfo;
	}
	
	public synchronized boolean isConnected(){
		return this.connInfo != null;
	}
	
	/**
	 * ͨ����ǰ�����ӷ������ݵ�������
	 * @param data			����������
	 * @param offset		��ʼ���͵�λ��ƫ��
	 * @param len			��Ҫ���͵����ݳ���
	 * @throws Exception
	 */
	public void sendData(byte[] data,int offset,int len) throws Exception{
		if(this.connInfo != null){
			this.connInfo.writeData(data, offset, len);
		}else{
			throw new Exception("δ�����쳣!");
		}
	}
	
	/**
	 * ����������Ƿ������ݵ����������ݵ������������Ķ��������Ķ����������Ķ�����Ϣ��
	 * ����������������������ķ�����
	 * ���ڰ������Զ���������
	 * @title
	 * @description
	 * @version      1.0
	 * @author       edmund
	 *
	 */
	private class DetectThread extends BasicTask{
		private boolean isStop = false;
		
		private String poolName = null;
		public void start(){
			try{
				this.poolName = "Fleety Socket["+FleetySocket.this.hashCode()+"] Detect Thread";
				PoolInfo pInfo = new PoolInfo(ThreadPool.SINGLE_TASK_LIST_POOL,1,1,false);
				ThreadPool pool = ThreadPoolGroupServer.getSingleInstance().createThreadPool(poolName, pInfo);
				pool.addTask(this);
			}catch(Exception e){
				e.printStackTrace();
			}
		}
		public boolean execute() throws Exception{
			try{
				this.run();
			}catch(Throwable e){
				e.printStackTrace();
			}finally{
				ThreadPoolGroupServer.getSingleInstance().removeThreadPool(this.poolName);
			}
			return true;
		}
		
		public void run(){
			while(!isStop){
				//���δ�������������
						//������Ӳ��ɹ�������һ���Ӻ��������
						if(!FleetySocket.this.connectSocket()){
							try{
								FleetyThread.sleep(FleetySocket.this.connectCycle);
							}catch(Exception e){}
							
							continue;
						}
				
				try{
					int num ;
					while(!isStop){
						synchronized(FleetySocket.this){
							
						}
						if(!FleetySocket.this.isConnected()){
							break;
						}
						num = FleetySocket.this.selector.select(60000);
						if(num > 0){
							ConnectSocketInfo connInfo;
							SelectionKey sKey;
							for(Iterator itr = FleetySocket.this.selector.selectedKeys().iterator();itr.hasNext();){
								sKey = (SelectionKey)itr.next();
								itr.remove();
								connInfo = (ConnectSocketInfo)sKey.attachment();
								CmdInfo[] cmdArr = FleetySocket.this.cmdReader.readCmd(connInfo);
								int cmdNum = (cmdArr == null?0:cmdArr.length);
								for(int i=0;i<cmdNum;i++){
									if(cmdArr[i] != null){
										connInfo.updateLastActiveTime();
										FleetySocket.this.cmdReleaser.releaseCmd(cmdArr[i]);
									}
								}
							}
						}
					}
				}catch(Exception e){
					e.printStackTrace();
				}
				
				FleetySocket.this._closeSocket();
			}
		}
		
		public void stopThread(){
			ThreadPoolGroupServer.getSingleInstance().removeThreadPool(this.poolName);
			this.isStop = true;
			if(FleetySocket.this.selector != null){
				try{
					FleetySocket.this.selector.wakeup();
				}catch(Exception e){}
			}
		}
	}
	
	private void switchSocket()
	{
		try
		{
			//�Ѿ������ӵ�����ַ
			if(isMain_current){
				return ;
			}
			Socket socket=new Socket(InetAddress.getByName(this.ip),this.port);
			socket.close();

			System.out.println("��IP����,���л�����IP!");
			this.ip_cur=this.ip;
			this.port_cur=this.port;
			this.isMain_current=true;
			this._closeSocket();
			connectSocket();
		}
		catch(Exception e)
		{
			System.out.println("�����л�����IPʧ��!");
			e.printStackTrace();
		}
	}
	public boolean isMain_current()
	{
		return isMain_current;
	}
	
}
