package server.flow.inst;

import com.fleety.base.InfoContainer;

import server.flow.IFlow;

public class QueryTaskInfoContainer extends InfoContainer implements IFlow{
	public static final String TASK_ID_FLAG = "task_id";
}
