/**
 * ���� Created on 2010-7-2 by edmund
 */
package server.var;

import java.io.File;
import java.io.FileInputStream;
import java.util.Hashtable;
import java.util.Iterator;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import com.fleety.base.Util;
import com.fleety.base.xml.XmlParser;
import com.fleety.server.BasicServer;

public class VarManageServer extends BasicServer{
	private static VarManageServer singleInstance = null;
	
	public static VarManageServer getSingleInstance(){
		if(singleInstance == null){
			synchronized(VarManageServer.class){
				if(singleInstance == null){
					singleInstance = new VarManageServer();
				}
			}
		}
		return singleInstance;
	}
	
	public VarManageServer(){
		this(null);
	}
	private VarManageServer parent = null;
	public VarManageServer(VarManageServer parent){
		this.parent = parent;
	}
	
	private String varFlag = "$";
	public boolean startServer(){
		String tempStr = this.getStringPara("var_flag");
		if(tempStr != null && tempStr.trim().length() > 0){
			this.varFlag = tempStr;
		}
		
		this.isRunning = this.loadCfg();
		if(this.isRunning()){
			Object varName,varValue;
			VarValueInfo varInfo;
			for(Iterator itr = this.varMapping.keySet().iterator();itr.hasNext();){
				varName = itr.next();
				
				varInfo = (VarValueInfo)this.varMapping.get(varName);;
				varValue = varInfo.getVarValue();
				varValue = this.updateValueByVar(varValue);
				
				this.varMapping.put(varName, new VarValueInfo(varInfo.isSystemProperty()+"",varValue));
				
				if(varInfo.isSystemProperty()){
					System.setProperty(varName.toString(), varValue.toString());
				}
			}
		}
		
		return this.isRunning;
	}
	
	private boolean loadCfg(){
		String cfgPath = this.getStringPara("cfg_path");
		if(cfgPath == null || cfgPath.trim().length() == 0){
			return true;
		}
		
		boolean isOk = true;
		String[] cfgPathArr = cfgPath.split(",");
		for(int i=0;i<cfgPathArr.length;i++){
			isOk = isOk & this._loadCfg(cfgPathArr[i]);
		}
		return isOk;
	}
	
	private boolean _loadCfg(String cfgPath){
		File f = new File(cfgPath);
		if(!f.exists()){
			return true;
		}
		FileInputStream in = null;
		try{
			in = new FileInputStream(cfgPath);
			Element root = XmlParser.parse(in);
			
			Node[] varNodeArr = Util.getElementsByTagName(root, "var");
			for(int i=0;i<varNodeArr.length;i++){
				this.loadOneVar(varNodeArr[i]);
			}
		}catch(Exception e){
			e.printStackTrace();
			return false;
		}finally{
			if(in != null){
				try{
					in.close();
				}catch(Exception e){}
			}
		}
		
		return true;
	}
	
	public void loadOneVar(Node varNode) throws Exception{
		String name = Util.getNodeAttr(varNode, "name");
		String systemProperty = Util.getNodeAttr(varNode, "system_property");
		Object value = Util.getNodeAttr(varNode, "value");
		if(name == null || name.trim().length() == 0){
			return ;
		}
		
		IValueCreator creator;
		Node cNode = Util.getSingleElementByTagName(varNode, "creator");
		String clsName = Util.getNodeAttr(cNode, "clsname");
		if(clsName != null){
			creator = (IValueCreator)Class.forName(clsName).newInstance();
			Node[] nodeArr = Util.getElementsByTagName(cNode, "para");
			Node tempNode;
			for(int i=0;i<nodeArr.length;i++){
				tempNode = nodeArr[i];
				creator.addPara(Util.getNodeAttr(tempNode, "key"), Util.getNodeAttr(tempNode, "value"));
			}
			Object _value = creator.createValue();
			if(_value != null){
				value = _value;
			}
		}
		
		if(value != null){
			this.varMapping.put(name, new VarValueInfo(systemProperty,value));
		}
	}

	public void stopServer(){
		this.isRunning = false;
		
		this.varMapping.clear();
	}
	
	private Hashtable varMapping = new Hashtable();
	public VarManageServer setVar(Object varName,Object varValue){
		if(!this.isRunning()){
			return this;
		}
		
		if(varValue != null){
			this.varMapping.put(varName, new VarValueInfo(varValue));
		}else{
			this.varMapping.remove(varName);
		}
		return this;
	}
	
	public String getVarStringValue(Object varName){
		if(!this.isRunning()){
			return null;
		}
		VarValueInfo value = (VarValueInfo)this.varMapping.get(varName);
		if(value == null){
			if(this.parent != null){
				return this.parent.getVarStringValue(varName);
			}
			return null;
		}
		return value.toString();
	}

	public Object getVarValue(Object varName){
		if(!this.isRunning()){
			return null;
		}
		VarValueInfo value = (VarValueInfo)this.varMapping.get(varName);
		if(value == null){
			if(this.parent != null){
				return this.parent.getVarValue(varName);
			}
			return null;
		}
		return value.getVarValue();
	}
	
	public boolean existVar(Object varName){
		if(!this.isRunning()){
			return false;
		}
		
		boolean isExist = this.varMapping.containsKey(varName);
		if(isExist){
			return true;
		}
		if(this.parent != null){
			return this.parent.existVar(varName);
		}
		return false;
	}
	
	public Object updateValueByVar(Object _value){
		if(!this.isRunning()){
			return null;
		}
		if(!(_value instanceof String)){
			return _value;
		}
		String value = (String)_value;
		if(_value == null){
			return value;
		}
		
		int flagLen = this.varFlag.length();
		
		String varName,varValue;
		int index1,index2;
		index1 = value.indexOf(varFlag);
		while(index1 >= 0){
			index2 = value.indexOf(varFlag, index1+flagLen);
			if(index2 > 0){
				varName = value.substring(index1+flagLen, index2);
				varValue = this.getVarStringValue(varName);
				if(varValue == null){
					index1 = index1+flagLen;
				}else{
					varValue = (String)this.updateValueByVar(varValue);
					value = value.substring(0, index1)+varValue+value.substring(index2+flagLen);
					index1 = index1 + varValue.length();
				}
			}else{
				break;
			}
			index1 = value.indexOf(varFlag,index1);
		}
		if(this.parent != null){
			return this.parent.updateValueByVar(value);
		}else{
			return value;
		}
	}
	
	private class VarValueInfo{
		private boolean isSystemProperty = false;
		private Object varValue = null;

		public VarValueInfo(Object varValue){
			this.varValue = varValue;
		}
		public VarValueInfo(String systemProperty,Object varValue){
			this.varValue = varValue;
			if(systemProperty != null){
				this.isSystemProperty = systemProperty.trim().equalsIgnoreCase("true"); 
			}
		}
		
		public boolean isSystemProperty(){
			return this.isSystemProperty;
		}
		public Object getVarValue(){
			return this.varValue;
		}
		
		public String toString(){
			if(this.varValue == null){
				return null;
			}
			return this.varValue.toString();
		}
	}
}
