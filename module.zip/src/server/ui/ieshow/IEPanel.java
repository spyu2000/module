/**
 * ���� Created on 2010-2-25 by edmund
 */
package server.ui.ieshow;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.Toolkit;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.WindowEvent;
import java.awt.event.WindowListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import nothome.mswindows.IECanvas;
import nothome.mswindows.IEEventListener;

public class IEPanel extends JPanel implements IEEventListener{
	private String urlPath = null;
	private IECanvas iePanel = null;
	private ICommand command = null;
    
	public IEPanel(){
        super();
	}	
	public void setCommand(ICommand command){
		this.command = command;
		if(this.command != null){
			this.command.setIECanvas(this.iePanel);
		}
	}
	
	public void setUrlPath(String urlPath){
		this.urlChanged = true;
		this.urlPath = urlPath;
	}
	public void go(){
		try{
            iePanel.setVisible(true);
            
		}catch(Exception e){
			e.printStackTrace();
		}
	}
	
	public void init(){
		Dimension dim = Toolkit.getDefaultToolkit().getScreenSize();
		this.setPreferredSize(dim);
		
		this.iePanel = new IECanvas(false);
		this.iePanel.addIEEventListener(this);
        this.iePanel.setSize(new Dimension(600,600));
		this.setLayout(new BorderLayout());
        JScrollPane scrollPane=new JScrollPane();
        scrollPane.setSize(new Dimension(800,600));
        scrollPane.getViewport().add(this.iePanel);
       
        
		this.add(this.iePanel, BorderLayout.CENTER);
        JButton button=new JButton("����IEPanel");
        

        
        button.addMouseListener(new MouseListener(){

            public void mouseClicked(MouseEvent e)
            {
               
                
            }

            public void mouseEntered(MouseEvent e)
            {
                // TODO Auto-generated method stub
                
            }

            public void mouseExited(MouseEvent e)
            {
                // TODO Auto-generated method stub
                
            }

            public void mousePressed(MouseEvent e)
            {
                // TODO Auto-generated method stub
                
            }

            public void mouseReleased(MouseEvent e)
            {
                // TODO Auto-generated method stub
                
            }
            
        });
        this.add(button,BorderLayout.NORTH);
       
        
		if(this.command != null){
			this.command.setIECanvas(this.iePanel);
		}		
		
//		synchronized(this){
//			if(!this.ieReady){
//				try{
//					this.wait(10000);
//				}catch(Exception e){
//					e.printStackTrace();
//				}
//			}
//		}
	}
	
	public void onStatusTextChange(String status) {
    }
    
    public void onTitleChange(String status) {
    }
    
    private boolean urlChanged = false;
    private boolean ieReady = false;
    public void onDocumentComplete(String status) {
        iePanel.setURL(this.urlPath);
        iePanel.resizeControl();
    }
    
    public void onBeforeNavigate2(String url) {
    }
    
    public void onNavigateComplete2(String status) {
    }
    
    public void onDownloadComplete() {
    }
    
    public void onProgressChange(int progress, int max) {
    }
    
    public void onCommandStateChange(int command, boolean enabled) {
    	
    }
    
    public void onQuit() {
    	
    }
    
    public boolean showContextMenu()  {
    	return true;
    }

	public void oneParamCallBack(String param1) {
		if(param1 == null){
			return ;
		}
		
		if(param1.equals("close")){
			System.exit(0);
		}
	}

	public void twoParamCallBack(String param1, String param2) {
		if(this.command != null){
			this.command.commandArrived(param1, param2);
		}
	}
    
    public static void main(String[] args){
        JFrame frame=new JFrame("����");
        frame.setPreferredSize(Toolkit.getDefaultToolkit().getScreenSize());
       
        
        JPanel test=new JPanel();
        
        test.setLayout(new BorderLayout());
        test.setPreferredSize(Toolkit.getDefaultToolkit().getScreenSize());
        test.add(new JLabel("aaa"),BorderLayout.NORTH);
        test.add(new JLabel("bbb"),BorderLayout.SOUTH);
        
        
        IEPanel panel=new IEPanel();
        panel.setCommand(new BasicCommand());
        panel.init(); 
        test.add(panel,BorderLayout.CENTER);
        
     
      JPanel contentPanel = (JPanel)frame.getContentPane();
      contentPanel.setLayout(new BorderLayout());
      contentPanel.add(test, BorderLayout.CENTER);
      
      //frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
      frame.addWindowListener(new WindowListener(){

        public void windowActivated(WindowEvent e)
        {
            // TODO Auto-generated method stub
            
        }

        public void windowClosed(WindowEvent e)
        {
            System.exit(0);
            
        }

        public void windowClosing(WindowEvent e)
        {
            System.exit(0);
            
        }

        public void windowDeactivated(WindowEvent e)
        {
            // TODO Auto-generated method stub
            
        }

        public void windowDeiconified(WindowEvent e)
        {
            // TODO Auto-generated method stub
            
        }

        public void windowIconified(WindowEvent e)
        {
            // TODO Auto-generated method stub
            
        }

        public void windowOpened(WindowEvent e)
        {
            // TODO Auto-generated method stub
            
        }
          
      }); 
      
      
      frame.pack();
      frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
      frame.setExtendedState(JFrame.MAXIMIZED_BOTH);
      frame.setVisible(true);

      panel.setUrlPath("http://google.cn");
       
//        frame.setState(JFrame.ICONIFIED);
        
//        
       
        
}}
