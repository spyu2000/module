/**
 * ���� Created on 2008-5-4 by edmund
 */
package com.fleety.util.pool;

public interface IPool{
	
}
