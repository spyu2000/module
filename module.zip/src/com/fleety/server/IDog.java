package com.fleety.server;

public interface IDog {
	public boolean detect();
}
