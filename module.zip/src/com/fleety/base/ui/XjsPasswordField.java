package com.fleety.base.ui;

import java.awt.Font;

import javax.swing.JPasswordField;

public class XjsPasswordField extends JPasswordField {
	public XjsPasswordField(){
		this.setFont(new Font("Dialog",Font.PLAIN,18));
	}
}
