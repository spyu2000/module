package com.fleety.base.ui;

import java.awt.Font;

import javax.swing.JTextField;

public class XjsTextField extends JTextField {
	public XjsTextField(){
		this.setFont(new Font("Dialog",Font.PLAIN,18));
	}
}
