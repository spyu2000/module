package test;

import java.util.Timer;
import java.util.TimerTask;

import com.fleety.base.InfoContainer;

import server.remote_execute_by_rmi.client.RemoteExecuteByRmiClient;
import server.remote_execute_by_rmi.client.help.RemoteCommandExecute;

public class ExitServer extends RemoteExecuteByRmiClient {
	public boolean startServer(){
		boolean isSuccess = super.startServer();
		
		new Timer().schedule(new TimerTask(){
			public void run(){
				sendExitCommand();
			}
		}, 10000, 600000);
		
		return isSuccess;
	}
	
	private void sendExitCommand(){
		try{
			System.out.println("���͹ر�����!");
			InfoContainer para = new InfoContainer();
			para.setInfo("op", "exit");
			InfoContainer result = (InfoContainer)this.remoteRmiExecute(RemoteCommandExecute.class.getName(), para, true);
			if(result.getBoolean("result")!=null &&  result.getBoolean("result") .booleanValue()){
				System.out.println("�رճɹ�!");
			}else{
				System.out.println("�ر�ʧ��!");
			}
			
		}catch(Exception e){
			e.printStackTrace();
			System.out.println("��������ʧ�ܡ�");
		}
	}
}
